
import { View, Text, ScrollView } from "react-native";
import { useEffect, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { analyzeFood } from "../utils/analyzeFood";
import { generateAdvice } from "../utils/generateAdvice";

const STORAGE_KEY = "foodData";
;

export default function Suggestions() {
  const [advice, setAdvice] = useState("Generating suggestions...");

  useEffect(() => {
    const loadData = async () => {
      const stored = await AsyncStorage.getItem(STORAGE_KEY);
      if (!stored) {
        setAdvice("Not enough data to generate suggestions.");
        return;
      }

      const allDaysData = JSON.parse(stored);
      const analysis = analyzeFood(allDaysData);
      const result = generateAdvice(analysis);

      setAdvice(result);
    };

    loadData();
  }, []);

  return (
    <ScrollView style={{ padding: 30 }}>
      <Text style={{ fontSize: 22, fontWeight: "bold", marginBottom: 10 }}>
        Suggestions for Next Week 🍽️
      </Text>
      <Text style={{ fontSize: 16, lineHeight: 24 }}>{advice}</Text>
    </ScrollView>
  );
}
