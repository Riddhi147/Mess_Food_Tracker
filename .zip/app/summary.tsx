import { View, Text, StyleSheet } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useEffect, useState } from "react";

export default function Summary() {
  const [counts, setCounts] = useState<Record<string, number>>({});

  useEffect(() => {
    AsyncStorage.getItem("foodData").then((res) => {
      if (!res) return;
      const data = JSON.parse(res);
      const tally: Record<string, number> = {};

      Object.values(data).forEach((day: any) => {
        day.forEach((food: string) => {
          tally[food] = (tally[food] || 0) + 1;
        });
      });

      setCounts(tally);
    });
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Weekly Summary</Text>

      {Object.entries(counts).map(([food, count]) => (
        <Text key={food} style={styles.item}>
          {food} — {count} times
        </Text>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#020617", padding: 20 },
  title: { color: "white", fontSize: 24, marginBottom: 20 },
  item: { color: "#cbd5f5", marginBottom: 8 },
});
