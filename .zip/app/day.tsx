import { View, Text, Pressable, StyleSheet, ScrollView } from "react-native";
import { useLocalSearchParams, router } from "expo-router";
import { useState, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

const STORAGE_KEY = "foodData";

const saveDayFood = async () => {
  const existing = await AsyncStorage.getItem(STORAGE_KEY);
  const data = existing ? JSON.parse(existing) : {};

  data[selectedDate] = selectedFoods;

  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(data));
};
const foods = [
  "Salads",
  "Oily",
  "Chicken",
  "Beef",
  "Pork",
  "Lentils",
  "Rice",
  "Pasta / Maggi",
  "Sweets",
  "Curd",
  "Fruits",
];

export default function DayScreen() {
  const { date } = useLocalSearchParams<{ date: string }>();
  const [selected, setSelected] = useState<string[]>([]);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem("foodData").then((res) => {
      if (!res || !date) return;
      const data = JSON.parse(res);
      if (data[date]) setSelected(data[date]);
    });
  }, [date]);

  function toggle(food: string) {
    setSelected((prev) =>
      prev.includes(food) ? prev.filter((f) => f !== food) : [...prev, food]
    );
  }

  async function saveDay() {
    if (!date) return;
    const stored = await AsyncStorage.getItem("foodData");
    const data = stored ? JSON.parse(stored) : {};
    data[date] = selected;
    await AsyncStorage.setItem("foodData", JSON.stringify(data));
    setSaved(true);
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Food on {date}</Text>

      <ScrollView style={{ marginBottom: 20 }}>
        {foods.map((food) => (
          <Pressable
            key={food}
            style={[styles.item, selected.includes(food) && styles.selected]}
            onPress={() => toggle(food)}
          >
            <Text style={styles.text}>{food}</Text>
          </Pressable>
        ))}
      </ScrollView>

      <Pressable style={styles.saveBtn} onPress={saveDay}>
        <Text style={styles.saveText}>Confirm</Text>
      </Pressable>

      {saved && (
        <View style={styles.afterSave}>
          <Pressable
            style={styles.secondaryBtn}
            onPress={() => router.replace("/calendar")}
          >
            <Text style={styles.secondaryText}>Back to Calendar</Text>
          </Pressable>

          <Pressable
            style={styles.secondaryBtn}
            onPress={() => router.push("/summary")}
          >
            <Text style={styles.secondaryText}>View Summary</Text>
          </Pressable>

          <Pressable
            style={styles.secondaryBtn}
            onPress={() => router.push("/suggestions")}
          >
            <Text style={styles.secondaryText}>Suggestions</Text>
          </Pressable>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#020617", padding: 20 },
  title: { color: "white", fontSize: 20, marginBottom: 15 },
  item: {
    backgroundColor: "#1e293b",
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
  },
  selected: { backgroundColor: "#22c55e" },
  text: { color: "white" },
  saveBtn: {
    backgroundColor: "#22c55e",
    padding: 15,
    borderRadius: 10,
    alignItems: "center",
  },
  saveText: { fontWeight: "600" },
  afterSave: { marginTop: 20, gap: 10 },
  secondaryBtn: {
    backgroundColor: "#1e293b",
    padding: 12,
    borderRadius: 10,
    alignItems: "center",
  },
  secondaryText: { color: "white" },
});

