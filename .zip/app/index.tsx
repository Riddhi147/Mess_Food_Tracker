import { View, Text, Pressable, StyleSheet } from "react-native";
import { router } from "expo-router";



export default function Index() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Mess Food Tracker 🍽️</Text>

      <Pressable
        style={styles.button}

        onPress={() => router.push("/calendar")}
      >
        <Text style={styles.buttonText}>Start Tracking</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#020617",
    justifyContent: "center",
    alignItems: "center",
  },
  title: {
    color: "white",
    fontSize: 26,
    fontWeight: "bold",
    marginBottom: 30,
  },
  button: {
    backgroundColor: "#22c55e",
    paddingVertical: 14,
    paddingHorizontal: 30,
    borderRadius: 10,
  },
  buttonText: {
    fontWeight: "600",
    color: "white",
  },
});













//--------------------------------------------------------------------------------------
// import { View, Text, Pressable, StyleSheet } from "react-native";
// import { useEffect } from "react";
// import AsyncStorage from "@react-native-async-storage/async-storage";
// import { router } from "expo-router";
//
// export default function Index() {
//   useEffect(() => {
//     const clearStorage = async () => {
//       await AsyncStorage.clear();
//       console.log("AsyncStorage cleared");
//     };
//
//     clearStorage();
//   }, []);
//
//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>Mess Food Tracker 🍽️</Text>
//
//       <Pressable
//         style={styles.button}
//         onPress={() => router.push("/calendar")}
//       >
//         <Text style={styles.buttonText}>Start</Text>
//       </Pressable>
//     </View>
//   );
// }
//
// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   title: {
//     fontSize: 24,
//     marginBottom: 20,
//     fontWeight: "600",
//   },
//   button: {
//     backgroundColor: "#4CAF50",
//     paddingHorizontal: 30,
//     paddingVertical: 12,
//     borderRadius: 8,
//   },
//   buttonText: {
//     color: "#fff",
//     fontSize: 16,
//     fontWeight: "600",
//   },
// });
