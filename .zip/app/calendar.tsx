import { View, Text, Pressable, StyleSheet, FlatList } from "react-native";
import { router } from "expo-router";

export default function Calendar() {
  const days = [
    "Day-1",
    "Day-2",
    "Day-3",
    "Day-4",
    "Day-5"
  ];

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Select a Day</Text>
      <FlatList
        data={days}
        keyExtractor={(item) => item}
        renderItem={({ item }) => (
          <Pressable
            style={styles.dayButton}
            onPress={() => router.push(`/day?date=${item}`)}
          >
            <Text style={styles.dayText}>{item}</Text>
          </Pressable>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#020617",
    padding: 20,
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    color: "white",
    marginBottom: 20,
  },
  dayButton: {
    padding: 15,
    marginBottom: 12,
    backgroundColor: "#1e293b",
    borderRadius: 10,
    alignItems: "center",
  },
  dayText: {
    color: "white",
    fontWeight: "600",
  },
});
