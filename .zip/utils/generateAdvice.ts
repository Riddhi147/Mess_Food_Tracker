export function generateAdvice(analysis: {
  oily: number;
  sugary: number;
  healthy: number;
  total: number;
}) {
  const advice: string[] = [];

  if (analysis.oily > analysis.total * 0.3) {
    advice.push(
      "The frequency of oily food consumption is higher than recommended. It is advised to limit fried meals to one or two days per week."
    );
  }

  if (analysis.sugary > analysis.total * 0.25) {
    advice.push(
      "A relatively high intake of sugary food items has been observed. Replacing sweets with fruits or curd is recommended."
    );
  }

  if (analysis.healthy < analysis.total * 0.4) {
    advice.push(
      "The intake of nutritionally balanced meals appears to be low. Increasing the consumption of vegetables, lentils, and salads is advised."
    );
  }

  if (advice.length === 0) {
    advice.push(
      "The meals recorded during the observed period are well balanced and nutritionally adequate. No major dietary corrections are required."
    );
  }

  return advice.join("\n\n");
}
