export function analyzeFood(daysData: Record<string, string[]>) {
  let oily = 0;
  let sugary = 0;
  let healthy = 0;
  let total = 0;

  const oilyFoods = ["pizza", "fried", "chips", "burger", "oily","Pasta / Maggi"];
  const sugaryFoods = ["sweet", "cake", "chocolate"];
  const healthyFoods = ["fruit", "salad", "Lentils", "vegetable", "rice"];

  Object.values(daysData).forEach(dayFoods => {
    dayFoods.forEach(food => {
      total++;
      const f = food.toLowerCase();

      if (oilyFoods.some(o => f.includes(o))) oily++;
      if (sugaryFoods.some(s => f.includes(s))) sugary++;
      if (healthyFoods.some(h => f.includes(h))) healthy++;
    });
  });

  return { oily, sugary, healthy, total };
}
